* --- Aghja Font --- *
Here is the last stable version of the file "Aghja.otf".

*Title*
Minimalist Latin font whose letters are connected.

*Copyright*
Copyright (c) 2014, Philippe Cochy with Reserved Font Name Aghja.
Aghja is a trademark registered at INPI in France.
This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied here, and is also available with a FAQ at:\nhttp://scripts.sil.org/OFL

*Web site*
http://pecita.net/Aghja/
