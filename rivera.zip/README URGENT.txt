FONT LICENSE : Free for personal Use

FONT NAME: RIVERA
Copyright © [2023] [Shinko Art Studio]

PERMISSION & CONDITIONS
You are allowed to:

Use the font for personal, academic, or commercial purposes

Modify the font to suit your design or language needs

Distribute the font with your work or on its own

Embed the font in documents, websites, apps, or products

You must NOT:

Sell the font by itself

Rename the font when distributing without making it clear it's a derivative

Claim authorship of the original font

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
THE AUTHOR IS NOT LIABLE FOR ANY DAMAGES RESULTING FROM THE USE OF THIS FONT SOFTWARE.